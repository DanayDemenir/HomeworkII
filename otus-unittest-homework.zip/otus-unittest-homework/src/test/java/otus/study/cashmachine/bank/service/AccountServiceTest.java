package otus.study.cashmachine.bank.service;


import org.junit.jupiter.api.Test;
import otus.study.cashmachine.bank.dao.AccountDao;
import otus.study.cashmachine.bank.service.impl.AccountServiceImpl;


public class AccountServiceTest {

    AccountDao accountDao;

    AccountServiceImpl accountServiceImpl;

    @Test
    void createAccountMock() {
// @TODO test account creation with mock and ArgumentMatcher
    }

    @Test
    void createAccountCaptor() {
//  @TODO test account creation with ArgumentCaptor
    }

    @Test
    void addSum() {
    }

    @Test
    void getSum() {
    }

    @Test
    void getAccount() {
    }

    @Test
    void checkBalance() {
    }
}
